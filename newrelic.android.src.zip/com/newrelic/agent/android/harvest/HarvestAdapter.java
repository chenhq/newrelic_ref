package com.newrelic.agent.android.harvest;

public class HarvestAdapter
  implements HarvestLifecycleAware
{
  public void onHarvestStart()
  {
  }

  public void onHarvestStop()
  {
  }

  public void onHarvestBefore()
  {
  }

  public void onHarvest()
  {
  }

  public void onHarvestFinalize()
  {
  }

  public void onHarvestError()
  {
  }

  public void onHarvestSendFailed()
  {
  }

  public void onHarvestComplete()
  {
  }

  public void onHarvestConnected()
  {
  }

  public void onHarvestDisconnected()
  {
  }

  public void onHarvestDisabled()
  {
  }
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.harvest.HarvestAdapter
 * JD-Core Version:    0.6.2
 */