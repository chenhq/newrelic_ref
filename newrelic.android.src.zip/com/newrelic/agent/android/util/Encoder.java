package com.newrelic.agent.android.util;

public abstract interface Encoder
{
  public abstract String encode(byte[] paramArrayOfByte);
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.util.Encoder
 * JD-Core Version:    0.6.2
 */