/*   */ package com.newrelic.agent.android.api.v1;
/*   */ 
/*   */ public enum DeviceForm
/*   */ {
/* 4 */   UNKNOWN, 
/* 5 */   SMALL, 
/* 6 */   NORMAL, 
/* 7 */   LARGE, 
/* 8 */   XLARGE;
/*   */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.api.v1.DeviceForm
 * JD-Core Version:    0.6.2
 */