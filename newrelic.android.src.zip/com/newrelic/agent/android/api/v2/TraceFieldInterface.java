package com.newrelic.agent.android.api.v2;

import com.newrelic.agent.android.tracing.Trace;

public abstract interface TraceFieldInterface
{
  public abstract void _nr_setTrace(Trace paramTrace);
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.api.v2.TraceFieldInterface
 * JD-Core Version:    0.6.2
 */