package com.newrelic.agent.android;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.BuildConfig
 * JD-Core Version:    0.6.2
 */