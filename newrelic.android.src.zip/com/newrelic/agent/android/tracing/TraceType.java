/*   */ package com.newrelic.agent.android.tracing;
/*   */ 
/*   */ public enum TraceType
/*   */ {
/* 7 */   TRACE, 
/* 8 */   NETWORK;
/*   */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.tracing.TraceType
 * JD-Core Version:    0.6.2
 */