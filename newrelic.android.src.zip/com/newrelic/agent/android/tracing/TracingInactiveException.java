package com.newrelic.agent.android.tracing;

public class TracingInactiveException extends Exception
{
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.tracing.TracingInactiveException
 * JD-Core Version:    0.6.2
 */