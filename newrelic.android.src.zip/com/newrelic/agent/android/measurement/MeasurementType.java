/*    */ package com.newrelic.agent.android.measurement;
/*    */ 
/*    */ public enum MeasurementType
/*    */ {
/*  7 */   Network, 
/*  8 */   HttpError, 
/*  9 */   Method, 
/* 10 */   Activity, 
/* 11 */   Custom, 
/* 12 */   Any, 
/* 13 */   Machine;
/*    */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.measurement.MeasurementType
 * JD-Core Version:    0.6.2
 */