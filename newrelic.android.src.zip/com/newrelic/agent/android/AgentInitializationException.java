/*   */ package com.newrelic.agent.android;
/*   */ 
/*   */ public class AgentInitializationException extends Exception
/*   */ {
/*   */   private static final long serialVersionUID = 2725421917845262499L;
/*   */ 
/*   */   public AgentInitializationException(String message)
/*   */   {
/* 7 */     super(message);
/*   */   }
/*   */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/newrelic.android.jar
 * Qualified Name:     com.newrelic.agent.android.AgentInitializationException
 * JD-Core Version:    0.6.2
 */