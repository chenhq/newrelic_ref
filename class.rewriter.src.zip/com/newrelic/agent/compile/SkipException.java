package com.newrelic.agent.compile;

final class SkipException extends RuntimeException
{
  private static final long serialVersionUID = 1L;
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.agent.compile.SkipException
 * JD-Core Version:    0.6.2
 */