package com.newrelic.agent.compile;

import java.lang.annotation.Annotation;

@interface InstrumentedMethod
{
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.agent.compile.InstrumentedMethod
 * JD-Core Version:    0.6.2
 */