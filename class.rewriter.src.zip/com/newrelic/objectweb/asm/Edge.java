package com.newrelic.objectweb.asm;

class Edge
{
  int a;
  Label b;
  Edge c;
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.objectweb.asm.Edge
 * JD-Core Version:    0.6.2
 */