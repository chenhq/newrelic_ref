/*     */ package com.newrelic.com.google.common.base.internal;
/*     */ 
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class Finalizer
/*     */   implements Runnable
/*     */ {
/*  51 */   private static final Logger logger = Logger.getLogger(Finalizer.class.getName());
/*     */   private static final String FINALIZABLE_REFERENCE = "com.newrelic.com.google.common.base.FinalizableReference";
/*     */   private final WeakReference<Class<?>> finalizableReferenceClassReference;
/*     */   private final PhantomReference<Object> frqReference;
/*     */   private final ReferenceQueue<Object> queue;
/* 106 */   private static final Field inheritableThreadLocals = getInheritableThreadLocalsField();
/*     */ 
/*     */   public static void startFinalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*     */   {
/*  80 */     if (!finalizableReferenceClass.getName().equals("com.newrelic.com.google.common.base.FinalizableReference")) {
/*  81 */       throw new IllegalArgumentException("Expected com.google.common.base.FinalizableReference.");
/*     */     }
/*     */ 
/*  85 */     Finalizer finalizer = new Finalizer(finalizableReferenceClass, queue, frqReference);
/*  86 */     Thread thread = new Thread(finalizer);
/*  87 */     thread.setName(Finalizer.class.getName());
/*  88 */     thread.setDaemon(true);
/*     */     try
/*     */     {
/*  91 */       if (inheritableThreadLocals != null)
/*  92 */         inheritableThreadLocals.set(thread, null);
/*     */     }
/*     */     catch (Throwable t) {
/*  95 */       logger.log(Level.INFO, "Failed to clear thread local values inherited by reference finalizer thread.", t);
/*     */     }
/*     */ 
/*  99 */     thread.start();
/*     */   }
/*     */ 
/*     */   private Finalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*     */   {
/* 114 */     this.queue = queue;
/*     */ 
/* 116 */     this.finalizableReferenceClassReference = new WeakReference(finalizableReferenceClass);
/*     */ 
/* 120 */     this.frqReference = frqReference;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     while (true)
/*     */       try
/*     */       {
/* 131 */         if (!cleanUp(this.queue.remove()))
/*     */           break;
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private boolean cleanUp(Reference<?> reference)
/*     */   {
/* 144 */     Method finalizeReferentMethod = getFinalizeReferentMethod();
/* 145 */     if (finalizeReferentMethod == null) {
/* 146 */       return false;
/*     */     }
/*     */ 
/*     */     do
/*     */     {
/* 153 */       reference.clear();
/*     */ 
/* 155 */       if (reference == this.frqReference)
/*     */       {
/* 160 */         return false;
/*     */       }
/*     */       try
/*     */       {
/* 164 */         finalizeReferentMethod.invoke(reference, new Object[0]);
/*     */       } catch (Throwable t) {
/* 166 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 173 */     while ((reference = this.queue.poll()) != null);
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */   private Method getFinalizeReferentMethod()
/*     */   {
/* 181 */     Class finalizableReferenceClass = (Class)this.finalizableReferenceClassReference.get();
/*     */ 
/* 183 */     if (finalizableReferenceClass == null)
/*     */     {
/* 192 */       return null;
/*     */     }
/*     */     try {
/* 195 */       return finalizableReferenceClass.getMethod("finalizeReferent", new Class[0]);
/*     */     } catch (NoSuchMethodException e) {
/* 197 */       throw new AssertionError(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Field getInheritableThreadLocalsField() {
/*     */     try {
/* 203 */       Field inheritableThreadLocals = Thread.class.getDeclaredField("inheritableThreadLocals");
/*     */ 
/* 205 */       inheritableThreadLocals.setAccessible(true);
/* 206 */       return inheritableThreadLocals;
/*     */     } catch (Throwable t) {
/* 208 */       logger.log(Level.INFO, "Couldn't access Thread.inheritableThreadLocals. Reference finalizer threads will inherit thread local values.");
/*     */     }
/*     */ 
/* 211 */     return null;
/*     */   }
/*     */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.com.google.common.base.internal.Finalizer
 * JD-Core Version:    0.6.2
 */