package com.newrelic.org.apache.commons.io.input;

public class TailerListenerAdapter
  implements TailerListener
{
  public void init(Tailer tailer)
  {
  }

  public void fileNotFound()
  {
  }

  public void fileRotated()
  {
  }

  public void handle(String line)
  {
  }

  public void handle(Exception ex)
  {
  }
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.org.apache.commons.io.input.TailerListenerAdapter
 * JD-Core Version:    0.6.2
 */