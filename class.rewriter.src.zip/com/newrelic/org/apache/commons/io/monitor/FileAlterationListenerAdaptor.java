package com.newrelic.org.apache.commons.io.monitor;

import java.io.File;

public class FileAlterationListenerAdaptor
  implements FileAlterationListener
{
  public void onStart(FileAlterationObserver observer)
  {
  }

  public void onDirectoryCreate(File directory)
  {
  }

  public void onDirectoryChange(File directory)
  {
  }

  public void onDirectoryDelete(File directory)
  {
  }

  public void onFileCreate(File file)
  {
  }

  public void onFileChange(File file)
  {
  }

  public void onFileDelete(File file)
  {
  }

  public void onStop(FileAlterationObserver observer)
  {
  }
}

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.org.apache.commons.io.monitor.FileAlterationListenerAdaptor
 * JD-Core Version:    0.6.2
 */