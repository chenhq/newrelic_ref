/*    */ package com.newrelic.org.dom4j.jaxb;
/*    */ 
/*    */ class JAXBRuntimeException extends RuntimeException
/*    */ {
/*    */   protected JAXBRuntimeException(Throwable cause)
/*    */   {
/* 25 */     super(cause);
/*    */   }
/*    */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.org.dom4j.jaxb.JAXBRuntimeException
 * JD-Core Version:    0.6.2
 */