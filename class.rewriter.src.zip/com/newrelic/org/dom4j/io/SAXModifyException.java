/*    */ package com.newrelic.org.dom4j.io;
/*    */ 
/*    */ class SAXModifyException extends RuntimeException
/*    */ {
/*    */   protected SAXModifyException(Throwable cause)
/*    */   {
/* 25 */     super(cause);
/*    */   }
/*    */ }

/* Location:           /home/think/Downloads/newrelic-android-4.120.0/lib/class.rewriter.jar
 * Qualified Name:     com.newrelic.org.dom4j.io.SAXModifyException
 * JD-Core Version:    0.6.2
 */