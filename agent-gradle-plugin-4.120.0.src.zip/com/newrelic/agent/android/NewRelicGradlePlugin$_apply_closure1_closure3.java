/*    */ package com.newrelic.agent.android;
/*    */ 
/*    */ import groovy.lang.Closure;
/*    */ import org.codehaus.groovy.runtime.GeneratedClosure;
/*    */ import org.codehaus.groovy.runtime.callsite.CallSite;
/*    */ 
/*    */ class NewRelicGradlePlugin$_apply_closure1_closure3 extends Closure
/*    */   implements GeneratedClosure
/*    */ {
/*    */   public NewRelicGradlePlugin$_apply_closure1_closure3(Object _outerInstance, Object _thisObject)
/*    */   {
/*    */     super(_outerInstance, _thisObject);
/*    */   }
/*    */ 
/*    */   public Object doCall(Object variant)
/*    */   {
/* 32 */     CallSite[] arrayOfCallSite = $getCallSiteArray(); arrayOfCallSite[0].call(arrayOfCallSite[1].callGetProperty(variant), "newRelicInstrumentTask");
/* 33 */     arrayOfCallSite[2].call(arrayOfCallSite[3].callGetProperty(variant), "newRelicDeinstrumentTask");
/*    */ 
/* 35 */     return arrayOfCallSite[4].call(arrayOfCallSite[5].callGroovyObjectGetProperty(this), arrayOfCallSite[6].call(arrayOfCallSite[7].call("[newrelic] Added instrumentation tasks to ", arrayOfCallSite[8].callGetProperty(variant)), " variant.")); return null;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     __$swapInit();
/*    */   }
/*    */ }

/* Location:           /home/think/newrelic/agent-gradle-plugin-4.120.0.jar
 * Qualified Name:     com.newrelic.agent.android.NewRelicGradlePlugin._apply_closure1_closure3
 * JD-Core Version:    0.6.2
 */